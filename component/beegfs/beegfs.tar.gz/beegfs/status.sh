#!/bin/bash

# status
echo "****** meta info ******"
/opt/midware/beegfs/sbin/beegfs-ctl cfgFile=/opt/data/beegfs/conf/beegfs-client.conf --listnodes --nodetype=meta --nicdetails

echo "****** storage info ******"
/opt/midware/beegfs/sbin/beegfs-ctl cfgFile=/opt/data/beegfs/conf/beegfs-client.conf --listnodes --nodetype=storage --nicdetails

echo "****** client info ******"
/opt/midware/beegfs/sbin/beegfs-ctl cfgFile=/opt/data/beegfs/conf/beegfs-client.conf --listnodes --nodetype=client --nicdetails

echo "****** client info ******"
/opt/midware/beegfs/sbin/beegfs-net cfgFile=/opt/data/beegfs/conf/beegfs-client.conf

echo "****** server info ******"
/opt/midware/beegfs/sbin/beegfs-check-servers cfgFile=/opt/data/beegfs/conf/beegfs-client.conf

echo "****** storage info ******"
/opt/midware/beegfs/sbin/beegfs-df cfgFile=/opt/data/beegfs/conf/beegfs-client.conf



