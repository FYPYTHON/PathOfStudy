#ifndef METADATA_H_
#define METADATA_H_

#include <common/Common.h>


#define META_ROOTDIR_ID_STR            "root"

#endif /*METADATA_H_*/
