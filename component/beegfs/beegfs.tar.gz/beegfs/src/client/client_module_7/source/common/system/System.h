#ifndef SYSTEM_H_
#define SYSTEM_H_

#include <common/Common.h>

extern char* System_getHostnameCopy(void);

#endif /*SYSTEM_H_*/
