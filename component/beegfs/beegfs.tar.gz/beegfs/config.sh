#!/bin/bash
# yum install kernel-devel.x86_64 -y
# yum install kernel.x86_64 -y

# beegfs-setup-storage help


mkdir -p /opt/data/beegfs
mkdir -p /opt/data/beegfs/conf
\cp /opt/midware/beegfs/conf/*.conf /opt/data/beegfs/conf


dataPath="/opt/data/beegfs"
cfgPath="/opt/data/beegfs/conf"
clientPath="/mnt/beegfs"
beegfsBin="/opt/midware/beegfs/sbin"
manageName="bgfs01"

mkdir -p ${dataPath}/beegfs_mgmtd
${beegfsBin}/beegfs-setup-mgmtd -c ${cfgPath}/beegfs-mgmtd.conf -p ${dataPath}/beegfs_mgmtd -f


mkdir -p ${dataPath}/beegfs_meta
${beegfsBin}/beegfs-setup-meta -c ${cfgPath}/beegfs-meta.conf -p ${dataPath}/beegfs_meta -s 2 -m ${manageName} -f

mkdir -p ${dataPath}/beegfs_storage
${beegfsBin}/beegfs-setup-storage -c ${cfgPath}/beegfs-storage.conf -p ${dataPath}/beegfs_storage -s 3 -i 301 -m ${manageName} -f

mkdir -p ${clientPath}
${beegfsBin}/beegfs-setup-client -c ${cfgPath}/beegfs-client.conf -m ${manageName} -f

${beegfsBin}/beegfs-setup-admon -c ${cfgPath}/beegfs-admon.conf -f


# client
mkdir -p /usr/lib/systemd/system
\cp /opt/midware/beegfs/systemd/beegfs-client.service /usr/lib/systemd/system
\cp /opt/midware/beegfs/init.d/beegfs-client /etc/init.d/
\cp /opt/midware/beegfs/conf/beegfs-client /opt/data/beegfs/conf
systemctl daemon-reload


