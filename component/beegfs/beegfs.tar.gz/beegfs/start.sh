#!/bin/bash

cfgPath="/opt/data/beegfs/conf"
mkdir -p /var/lock/subsys
# start mgmtd
# systemctl start beegfs-mgmtd
/opt/midware/beegfs/sbin/beegfs-mgmtd cfgFile=${cfgPath}/beegfs-mgmtd.conf pidFile=/var/run/beegfs-mgmtd.pid
if [ "$?"x != "0"x ];then
    echo "mgmtd start error"
    exit -1
fi
touch /var/lock/subsys/beegfs-mgmtd

# systemctl start beegfs-meta
/opt/midware/beegfs/sbin/beegfs-meta cfgFile=${cfgPath}/beegfs-meta.conf pidFile=/var/run/beegfs-meta.pid
if [ "$?"x != "0"x ];then
    echo "meta start error"
    exit -1
fi
touch /var/lock/subsys/beegfs-meta

# systemctl start beegfs-storage
#PIDFILE=/var/run/beegfs-storage.pid
#mkdir -p /var/lock/subsys
/opt/midware/beegfs/sbin/beegfs-storage cfgFile=${cfgPath}/beegfs-storage.conf pidFile=/var/run/beegfs-storage.pid
if [ "$?"x != "0"x ];then
    echo "storage start error"
    exit -1
fi
touch /var/lock/subsys/beegfs-storage


# start helperd
/opt/midware/beegfs/sbin/beegfs-helperd cfgFile=${cfgPath}/beegfs-helperd.conf pidFile=/var/run/beegfs-helperd.pid
if [ "$?"x != "0"x ];then
    echo "helperd start error"
    exit -1
fi
touch /var/lock/subsys/beegfs-helperd

# admon
/opt/midware/beegfs/sbin/beegfs-admon cfgFile=${cfgPath}/beegfs-admon.conf pidFile=/var/run/beegfs-admon.pid
if [ "$?"x != "0"x ];then
    echo "admon start error"
    exit -1
fi
touch /var/lock/subsys/beegfs-admon


################################
# client

systemctl start beegfs-client
if [ "$?"x != "0"x ];then
    echo "client start error"
    exit -1
fi
exit 0


