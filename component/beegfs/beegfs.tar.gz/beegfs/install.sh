#!/bin/bash

rm -rf /opt/midware/beegfs
cd /opt/midware
if [ ! -f "beegfs.tar.gz" ];then
    echo "[error] beegfs.tar.gz not find."
    exit -1
fi
tar -zxvf beegfs.tar.gz
\cp /opt/midware/beegfs/systemd/beegfs-client.service /usr/lib/systemd/system

cd /opt/midware/beegfs/src/client/client_module_7/build
make && make install

# start mgmtd
# systemctl start beegfs-mgmtd
# systemctl start beegfs-meta
# systemctl start beegfs-storage


# start client
# systemctl start beegfs-helperd
# systemctl start beegfs-client

# admon
# systemctl start beegfs-admon





