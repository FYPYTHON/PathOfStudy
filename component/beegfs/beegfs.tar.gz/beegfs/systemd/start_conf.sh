#!/bin/bash

mkdir -p /opt/beegfs/systemd
cd /opt/beegfs/systemd

\cp /usr/lib/systemd/system/beegfs-mgmtd.service ./

\cp /usr/lib/systemd/system/beegfs-admon.service ./

\cp /usr/lib/systemd/system/beegfs-storage.service ./

\cp /usr/lib/systemd/system/beegfs-meta.service ./

\cp /usr/lib/systemd/system/beegfs-helperd.service ./

\cp /usr/lib/systemd/system/beegfs-client.service ./

chmod +x *.service

