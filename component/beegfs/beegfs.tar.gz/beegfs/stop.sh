#!/bin/bash

. /opt/midware/beegfs/conf/lib/start-stop-functions.beegfs-admon
. /opt/midware/beegfs/conf/lib/init-multi-mode.beegfs-admon

# stop mgmtd
#systemctl stop beegfs-mgmtd
#kill -9 `ps -ef | grep beegfs-mgmtd | grep -v grep | awk '{print $2}'`
killproc -p /var/run/beegfs-mgmtd.pid beegfs-mgmtd
rm -rf /var/lock/subsys/beegfs-mgmtd
echo "mgmtd stopped"

#systemctl stop beegfs-meta
#kill -9 `ps -ef | grep beegfs-meta | grep -v grep | awk '{print $2}'`
killproc -p /var/run/beegfs-meta.pid beegfs-meta
rm -rf /var/lock/subsys/beegfs-meta
echo "meta stopped"


#systemctl stop beegfs-storage
#kill -9 `ps -ef | grep beegfs-storage | grep -v grep | awk '{print $2}'`
killproc -p /var/run/beegfs-storage.pid beegfs-storage
rm -rf /var/lock/subsys/beegfs-storage
echo "storage stoppend"

# stop helpd
#systemctl stop beegfs-helperd
#kill -9 `ps -ef | grep beegfs-helperd | grep -v grep | awk '{print $2}'`
killproc -p /var/run/beegfs-helperd.pid beegfs-helperd
rm -rf /var/lock/subsys/beegfs-helperd
echo "helperd stopped"




# admon
#systemctl stop beegfs-admon
#kill -9 `ps -ef | grep beegfs-admon | grep -v grep | awk '{print $2}'`
killproc -p /var/run/beegfs-admon.pid beegfs-admon
rm -rf /var/lock/subsys/beegfs-admon
echo "admon stopped"


######################
# stop client
systemctl stop beegfs-client
echo "client stoppend"

kill -9 `ps -ef | grep beegfs | grep -v grep | awk '{print $2}'`
echo "beegfs killed"


